from turtle import Turtle
import random
import time

class Ball(Turtle):

    def __init__(self):
        super().__init__()
        self.ball_y = random.randint(-290, 290)
        self.ball_angle = random.randint(20, 340)
        print(self.ball_angle)
        self.ball = Turtle()

    def create_ball(self):
        self.ball.color("white")
        self.ball.shape("circle")
        self.ball.penup()
        self.ball.setheading(self.ball_angle)
        self.ball.goto(0, self.ball_y)

    def reflection(self):
        if self.ball.xcor() > 0 and self.ball.ycor() > 0:  # 1st
            self.right(2 * self.ball_angle)
        elif self.ball.xcor() < 0 and self.ball.ycor() > 0:  # 2nd
            self.right(2 * self.ball_angle)
        elif self.ball.xcor() < 0 and self.ball.ycor() < 0:  # 3rd
            self.right(2 * (self.ball_angle-180))
        elif self.ball.xcor() > 0 and self.ball.ycor() < 0:  # 4th
            self.right((2 * self.ball_angle) - 360)

    def move_ball(self):
        if self.ball.ycor() < 285 and self.ball.ycor() > -285:
            self.ball.forward(10)
        else:
            self.setheading(180)
            print(self.ball.heading())
            # self.ball.forward(10)

