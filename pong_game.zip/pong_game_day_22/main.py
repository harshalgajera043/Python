from turtle import Screen
from plate import Plate
from court import Court
from ball import Ball
import time

screen = Screen()
screen.setup(800, 600)
screen.bgcolor("black")
screen.title("ENJOY PONG!!")
screen.tracer(0)
game_on = True

# Plate
plate = Plate()
plate.plate()
r_plate = plate.plate_list[0]
l_plate = plate.plate_list[1]
# print(r_plate)


# Boundry_court
center = Court()
center.court()

# Create Ball
main_ball = Ball()
main_ball.create_ball()

# controlling plate using keywboard
screen.listen()
screen.onkey(key="w", fun=plate.plate_up_left)  # Multiuser Game
screen.onkey(key="s", fun=plate.plate_down_left)  # Multiuser Game
screen.onkey(key="Up", fun=plate.plate_up_right)
screen.onkey(key="Down", fun=plate.plate_down_right)
# screen.update()

while game_on:
    screen.update()
    time.sleep(0.1)
    main_ball.move_ball()








screen.exitonclick()

