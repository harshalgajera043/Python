from ball import Ball
from turtle import Turtle
from plate import Plate

class ScoreBoard(Turtle, Ball):

    def __init__(self):
        super().__init__()
        self.point_player_at_left = 0
        self.point_player_at_right = 0

    def score_point_right(self):
        if self.ball.xcor() < -390:
            self.point_player_at_left += 1
        elif self.ball.xcor() > 390:
            self.point_player_at_right += 1












        # if self.plate_list[0].distance(self.ball) < 10:

