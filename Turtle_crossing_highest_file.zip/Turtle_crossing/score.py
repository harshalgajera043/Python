from turtle import Turtle


class ScoreBoard(Turtle):

    def __init__(self):
        super().__init__()
        self.sleep_time = 0.5
        self.color("black")
        self.penup()
        self.current_score = 1
        with open("Max_level.txt") as level:
            self.max_level = level.read()
        self.goto(-390, 270)
        self.display_score()
        self.hideturtle()

    def display_score(self):
        self.write(f"Current Level: {self.current_score} Max Level: {self.max_level}", move=False, align='left', font=('Courier', 16, 'normal'))

    def increase_level(self, turtle_object):
        if turtle_object.ycor() > 270:
            self.current_score += 1
            self.clear()
            self.sleep_time *= 0.5
            turtle_object.goto(0, -290)
            turtle_object.move_distance += 2
            self.display_score()
            self.remember_score()

    def game_over(self):
        self.penup()
        self.home()
        self.write(arg=f"ohhoo!! GAME OVER 😣😢😥😭\n You completed {self.current_score} levels", move=False,
                   align="center", font=('Courier', 28, 'bold'))
        self.hideturtle()

    def remember_score(self):
        if self.current_score > int(self.max_level):
            with open("Max_level.txt", mode="w") as level:
                level.write(f"{self.current_score}")
