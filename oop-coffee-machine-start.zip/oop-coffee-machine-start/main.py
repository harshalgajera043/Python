from menu import Menu
from menu import MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

money_machine = MoneyMachine()  # money_machine object from MoneyMachine class
coffee_maker = CoffeeMaker()  # coffee_maker object from CoffeeMaker class
coffee_menu = Menu()  # coffee_menu object from Menu class

is_on = True
while is_on:
    print(f"Chose your drink from menu. {coffee_menu.get_items()}")
    user_order = input("Which coffee would you like to have?\n")
    if user_order == "report":
        coffee_maker.report()
        money_machine.report()
    elif user_order == "off":
        is_on = False
    else:
        item = coffee_menu.find_drink(user_order)
        sufficient = coffee_maker.is_resource_sufficient(item)
        if sufficient:
            print(f"Your bill is {item.cost}")
            payment_status = money_machine.make_payment(item.cost)
            if payment_status:
                coffee_maker.make_coffee(item)