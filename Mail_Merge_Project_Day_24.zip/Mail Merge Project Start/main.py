PLACEHOLDER = "[name]"
SENT_BY = "Angela"

with open("./Input/Names/invited_names.txt") as names:
    name_list = names.readlines()
    print(name_list)

with open("./Input/Letters/starting_letter.txt") as letter:
    texts = letter.read()
    for name in name_list:
        update_texts = texts.replace(PLACEHOLDER, name.strip())
        updated_texts = update_texts.replace(SENT_BY, "Harshal")
        with open(f"./Output/ReadyToSend/letter_for_{name.strip()}.txt", "w") as invitation:
            invitation.write(updated_texts)
        # print(texts)

