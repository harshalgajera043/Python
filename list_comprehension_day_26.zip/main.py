import pandas

file_1 = pandas.read_csv("file1.txt", header = None)
file_2 = pandas.read_csv("file2.txt", header = None)
list_1 = list(file_1[0])
list_2 =  list(file_2[0])

result = [number for number in list_1 if number in list_2]

# Write your code above 👆

print(result)


