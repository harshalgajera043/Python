class QuestionModel:

    def __init__(self, q_text, q_answer):
        self.question = q_text
        self.answer = q_answer

# my_question = QuestionModel("geffdv", "fdvbfd")
# print(my_question.question)

