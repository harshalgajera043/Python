from question_model import QuestionModel
from data import question_data
from quiz_brain import  AskUserQuestion  # CheckAnswer
# import random
#
# play_on = True
# current_score = 0
# while play_on:
#     choice = random.choice(question_data)
#     my_question = QuestionModel(choice["text"], choice["answer"])
#     print(my_question.question)
#     # print(my_question.answer)
#     user_answer = input("\'True\'\\'False\': ")
#     check_answer = CheckAnswer()
#     quiz_result = check_answer.condition(choice["answer"], user_answer)
#     # check_answer.judge_answer(quiz_result, current_score, play_on)
#     if quiz_result:
#         current_score += 1
#         print(f"Your current score is {current_score}")
#         print("Keep Playing")
#     else:
#         play_on = False
#         print(f"Your final score is {current_score}")

question_bank = []
for question in question_data:
    question_text = question["question"]
    question_answer = question["correct_answer"]
    new_question = QuestionModel(question_text, question_answer)
    question_bank.append(new_question)

quiz = AskUserQuestion(question_bank)
while quiz.still_has_question():
    quiz.next_question()

print("You've completed the quiz")
print(f"Your final score is {quiz.score}/{quiz.question_number}")
