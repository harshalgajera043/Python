# class CheckAnswer:
#     def condition(self, answer, user_choice):
#         if answer.lower() == user_choice.lower():
#             return True
#         else:
#             return False
#
#     # def judge_answer(self, condition_result, current_score, mode):
#     #     if condition_result:
#     #         current_score += 1
#     #         print(f"Your current score is {current_score}")
#     #         print("Keep Playing")
#     #     else:
#     #         mode = False
#     #         print(f"Your final score is {current_score}")

class AskUserQuestion:

    def __init__(self, quiz_list):
        self.question_number = 0
        self.question_list = quiz_list
        self.play_on = True
        self.score = 0

    # def next_question(self):
    #     while self.play_on:
    #         current_question = self.question_list[self.question_number]
    #         self.question_number += 1
    #         user_answer = input(f"Q.{self.question_number}: {current_question.question} (True/False)? ")
    #         if current_question.answer == user_answer:
    #             self.score += 1
    #             print("You got this question correct")
    #             print(f"Your current score is {self.score}/{self.question_number}")
    #         else:
    #             self.play_on = False
    #             print("Ohhoo, bad luck that's a wrong answer")
    #             print(f"Your final score is {self.score}/{self.question_number}")

    def still_has_question(self):
        return self.question_number < len(self.question_list)

    def next_question(self):
        current_question = self.question_list[self.question_number]
        self.question_number += 1
        user_answer = input(f"Q.{self.question_number}: {current_question.question} (True/False)? ")
        self.check_answer(user_answer, current_question.answer)

    def check_answer(self, user_input, correct_answer):
        if user_input.lower() == correct_answer.lower():
            self.score += 1
            print(f"You got it right!!")
        else:
            print(f"That's wrong!!")
            print(f"correct answer is {correct_answer.capitalize()}")
        print(f"Your current score is {self.score}/{self.question_number}")
        print("")

        # if self.question_number == len(self.question_list):
        #     print("You've completed the quiz")
        #     print(f"Your Final score is {self.score}/{self.question_number}")
