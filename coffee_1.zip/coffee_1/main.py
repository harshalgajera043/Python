from collect import CollectPayment
from make_my_order import MyOrder
from make_my_drink import MakeCoffee
from coffee_data import MENU, resources
coin_dict = {
    "coin_1": 0.01,
    "coin_2": 0.05,
    "coin_3": 0.1,
    "coin_4": 0.25,
}

coffee = MyOrder()
order_list = coffee.my_order(MENU)
my_order = input(f"What would you like to have? {order_list}")
cost = MENU[my_order]["cost"]
print(cost)
coffee_payment = CollectPayment(cost)
if coffee_payment.pay_coins(coin_dict):
    MakeCoffee.make_coffee()

