class MyOrder:

    def my_order(self, menu):
        self.coffee_list = ""
        for coffee in menu:
            self.coffee_list += coffee
            for i in range(len(menu)-1):
                self.coffee_list += "|"
        return self.coffee_list
