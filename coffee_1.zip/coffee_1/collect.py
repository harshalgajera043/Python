class CollectPayment:

    def __init__(self, price):
        self.cost = price
        self.amount_paid = 0

    def report(self):
        print(self.amount_paid)

    def pay_coins(self, coin_dict):
        for coin in coin_dict:
            number_of_coins = float(input(f"How many {coin}? "))
            value = number_of_coins * coin_dict[coin]
            self.amount_paid += value
        if self.cost <= self.amount_paid:
            print(f"Here is your ${round(self.amount_paid-self.cost,2)}.")
            return self.cost <= self.amount_paid
        else:
            return f"you are not having sufficient funds!! we have initiated your repayment"

