class MakeCoffee:

    def report(self, present_resources):
        for ingredient in present_resources:
            print(f"{ingredient} = {present_resources[ingredient]}")

    def make_coffee(self, resources, coffee):
        for ingredient in resources[coffee]["ingredients"]:




