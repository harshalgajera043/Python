from turtle import Turtle
ALIGNMENT = "center"
FONT = ('Arial', 16, 'normal')

class ScoreBoard(Turtle):

    def __init__(self):
        self.score = 0
        super().__init__()
        # self.high_score = 0
        with open("Highscore.txt") as file:
            self.high_score = int(file.read())
        self.color("white")
        self.penup()
        self.goto(0, 270)
        self.message()

    def message(self):
        self.clear()
        self.write(arg=f"Score: {self.score}  Highscore: {self.high_score}", move=False, align=ALIGNMENT, font=FONT)
        self.hideturtle()

    def increase_score(self):
        self.score += 1
        # self.clear()
        self.color('white')
        self.message()

    def reset(self):
        if self.score > self.high_score:
            self.high_score = self.score
            with open("Highscore.txt", mode="w") as file:
                file.write(f"{self.high_score}")
        self.score = 0
        self.message()




    # def game_over(self):
    #     self.clear()
    #     self.goto(0, 0)
    #     self.message()


