from turtle import Turtle
import random

CAR_COLOR_LIST = ["black", "red", "blue", "yellow", "green", "pink", "purple"]


class Car(Turtle):  # Inheriting Turtle class inside Car class to access all the functionality of Turtle in Car

    def __init__(self):
        super().__init__()
        self.list_of_car = []
        # for _ in range(0, 10):
        self.create_car()
        #     self.list_of_car.append(car)
        # print(self.list_of_car)

    def create_car(self):
        self.color(random.choice(CAR_COLOR_LIST))
        self.shape("square")
        self.penup()
        self.shapesize(stretch_wid=1, stretch_len=2.5)
        self.goto(430, random.randint(-250, 250))
        if self.xcor() > -400:
            self.move_car()

    def move_car(self):
        self.x_move = 20
        self.x_cor = self.xcor()
        self.new_x = self.xcor() - self.x_move
        self.goto(self.new_x, self.ycor())
