from turtle import Turtle


class ScoreBoard(Turtle):

    def __init__(self):
        super().__init__()
        self.sleep_time = 0.5
        self.color("black")
        self.penup()
        self.current_score = 0
        self.goto(-390, 270)
        self.display_score()
        self.hideturtle()

    def display_score(self):
        self.write(f"Current Level: {self.current_score}", move=False, align='left', font=('Courier', 16, 'normal'))

    def increase_level(self, turtle_object):
        if turtle_object.ycor() > 270:
            self.current_score += 1
            self.clear()
            self.sleep_time *= 0.5
            turtle_object.goto(0, -290)
            self.display_score()

    def game_over(self):
        self.penup()
        self.home()
        self.write(arg=f"ohhoo!! GAME OVER 😣😢😥😭\n You completed {self.current_score} levels", move=False,
                   align="center", font=('Courier', 28, 'bold'))
        self.hideturtle()
